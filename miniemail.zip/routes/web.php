<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
header('Access-Control-Allow-Origin:*');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: OPTIONS, HEAD, GET,POST,DELETE');

Route::get('/', function () {
    return view('welcome');
});
Route::get('/loads_email','EmailController@loads_email')->name('loads_email');
Route::post('/email_actions','EmailController@email_actions')->name('email_actions');
Route::get('/search_email_actions','EmailController@search_email_actions')->name('search_email_actions');

Route::get('/admin_count_all','AdminEmailController@admin_count_all')->name('admin_count_all');
Route::get('/admin_view_clients','AdminEmailController@admin_view_clients')->name('admin_view_clients');
Route::get('/admin_count_user','AdminEmailController@admin_count_user')->name('admin_count_user');
Route::get('/admin_search_client','AdminEmailController@admin_search_client')->name('admin_search_client');
Route::get('/admin_view_user','AdminEmailController@admin_view_user')->name('admin_view_user');

//Crud test
Route::get('/test_check','TestController@test_check')->name('test_check');
Route::post('/test_login','TestController@test_login')->name('test_login');
Route::get('/test_select','TestController@test_select')->name('test_select');
Route::post('/test_insert','TestController@test_insert')->name('test_insert');
Route::get('/test_edit','TestController@test_edit')->name('test_edit');
Route::get('/test_delete','TestController@test_delete')->name('test_delete');
//Crud test

Route::get('/testemail','TestController@testemail')->name('testemail');//notification
Route::get('/users_loginpage','RegisterController@users_loginpage')->name('users_loginpage');//notification
Route::get('/admins_loginpage','RegisterController@admins_loginpage')->name('admins_loginpage');//notification
Route::get('/register_detect_country','RegisterController@register_detect_country')->name('register_detect_country');
Route::get('/users_resendemailpage','RegisterController@users_resendemailpage')->name('users_resendemailpage');//notification
Route::get('/admins_resendemailpage','RegisterController@admins_resendemailpage')->name('admins_resendemailpage');//notification
Route::post('/Admin_forgetpassword','RegisterController@Admin_forgetpassword')->name('Admin_forgetpassword');//notification
Route::post('/resend_email','RegisterController@resend_email')->name('resend_email');//notification
Route::get('/users_newpasswordpage','RegisterController@users_newpasswordpage')->name('users_newpasswordpage');//notification
Route::get('/admins_newpasswordpage','RegisterController@admins_newpasswordpage')->name('admins_newpasswordpage');//notification
Route::post('/new_password','RegisterController@new_password')->name('new_password');//notification



Route::post('/change_profile','ProfileController@change_profile')->name('change_profile');
Route::post('/change_audio_profile','ProfileController@change_audio_profile')->name('change_audio_profile');
Route::post('/report_profile','ProfileController@report_profile')->name('report_profile');


//Route::get('/profile','ProfileController@profile')->name('profile')->middleware('auth:Admin','auth');
Route::get('/profile','ProfileController@profile')->name('profile');

Route::get('/get_profile_detail','ProfileController@get_profile_detail')->name('get_profile_detail');

Route::get('/users_resend_confirmationpage','RegisterController@users_resend_confirmationpage')->name('users_resend_confirmationpage');
Route::get('/admins_resend_confirmationpage','RegisterController@admins_resend_confirmationpage')->name('admins_resend_confirmationpage');
Route::post('/reset_with_phone','RegisterController@reset_with_phone')->name('reset_with_phone');
Route::post('/User_forgetpassword','RegisterController@User_forgetpassword')->name('User_forgetpassword');
Route::get('/unverified','RegisterController@unverified')->name('unverified');
Route::get('/logout','RegisterController@logout')->name('logout');
//Route::get('/logout','RegisterController@logout')->name('logout');
Route::get('/logintest','RegisterController@logintest')->name('logintest');
Route::get('/test','TestController@test')->name('test');
/* users Action */
/*user Authentiation */
Route::get('/confirm_email','RegisterController@confirm_email')->name('confirm_email');
Route::post('/User_newpassword','RegisterController@User_newpassword')->name('User_newpassword');
Route::get('/sendemail','RegisterController@sendemail')->name('sendemail');
Route::post('/login','RegisterController@login')->name('login');

Route::get('/otppage','RegisterController@otppage')->name('otppage');
Route::post('/otp_confirmation','RegisterController@otp_confirmation')->name('otp_confirmation');
Route::get('/adminforgetpage','RegisterController@adminforgetpage')->name('adminforgetpage');
Route::get('/forgetpage','RegisterController@forgetpage')->name('forgetpage');
Route::get('/loginpage','RegisterController@loginpage')->name('loginpage');
Route::post('/register','RegisterController@register')->name('register');
Route::get('/registerpage','RegisterController@registerpage')->name('registerpage');
/*user Authentiation */

Route::get('/get_componentblade','ProfileController@get_componentblade')->name('get_componentblade');


//serch i will do it later
Route::post('/search_address_profile','ProfileController@search_address_profile')->name('search_address_profile')->middleware('auth');


/* users Action */



/* Admin Action */

/*admin Authentication*/
Route::post('/signin','RegisterController@signin')->name('signin');
Route::get('/signinpage','RegisterController@signinpage')->name('signinpage');
Route::post('/signup','RegisterController@signup')->name('signup');
Route::get('/signuppage','RegisterController@signuppage')->name('signuppage');

/*admin Authentication*/






/* Admin Action */

/*Action clients to owner of Products */

/*search nearest first*/
Route::get('/search_address_profile','ProfileController@search_address_profile')->name('search_address_profile');//from clients

/*First Step*/







/*Action clients to owner of Products */



