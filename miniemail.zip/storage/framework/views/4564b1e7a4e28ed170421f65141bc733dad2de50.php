
  
Table_Medorders:function(){
 
     oTable = $('#Table_orders').DataTable({
           "processing": false,
           "serverSide": true,
               "destroy":true,
               "responsive": true,
                ajax: {
       url:"<?php echo e(route('table_orders')); ?>",
        type:"post",
        data:{
          "type_order":'<?php echo e(env('ordertype1')); ?>',
          "_token":'<?php echo e(csrf_token()); ?>'
        }
        
         
    },"columns": [






<?php if(Auth::guard('Admin')->check()): ?>
                                      <?php if(Auth::guard('Admin')->user()->platform==env('Standard')): ?>
                                      <?php echo $__env->make('components.Table.jscomponents.table_Medorder_pharmacyjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        
                                       <?php else: ?>
                                       <?php echo $__env->make('components.Table.jscomponents.table_Medorder_Superjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                       <?php endif; ?>
 
                                      <?php elseif(Auth::check()): ?>
                                      <?php if(Auth::user()->platform==env('Client')): ?>
                                      <?php echo $__env->make('components.Table.jscomponents.table_Medorder_Clientjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        
                                       <?php else: ?>
                                     <div>none</div>   
                                       <?php endif; ?>  
                                     
                                      <?php else: ?>
  
                                      <?php endif; ?>
                                     




    
    ],
       
       
                   
      });

     new $.fn.dataTable.FixedHeader( oTable );


} ,  
  
  <?php /**PATH E:\amyapp\medonline\medonline\resources\views/components/Table/Table_Medordersjs.blade.php ENDPATH**/ ?>