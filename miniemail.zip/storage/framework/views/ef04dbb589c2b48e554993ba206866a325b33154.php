{data:'id',name:'id'},
{data:'name',name:'name'},
{data:'email',name:'email'},
{data:'tel',name:'tel'},
{data:'platform',name:'platform'},
{data:'phys_address',name:'phys_address'},
{data:'created_at',name:'created_at'},
{data:'updated_at',name:'updated_at'},
{data: 'action',name:'action'},     <?php /**PATH E:\Assessment test\miniemail\resources\views/components/Table/jscomponents/table_admin_Superjs.blade.php ENDPATH**/ ?>