
 //table   
Table_admin:function(){
     //
     oTable = $('#Table_admin').DataTable({
           "processing": false,
           "serverSide": true,
               "destroy":true,
               "responsive": true,
                ajax: {
       url:"<?php echo e(route('table_admin')); ?>",
        type:"post",
        data:{
          "_token":'<?php echo e(csrf_token()); ?>'
        }
        
         
    },"columns": [

//data




<?php echo $__env->make('components.Table.jscomponents.table_admin_Superjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                     

//data


    
    ],
       
       
                   
      });

     new $.fn.dataTable.FixedHeader( oTable );
//

},    
  
  //table<?php /**PATH E:\amyapp\medonline\medonline\resources\views/components/Table/Table_adminjs.blade.php ENDPATH**/ ?>