<tr class="Standard d-none">
<th>Client</th>
    <th>Product Name</th>
    
    <th>Price</th>
    <th>Delivery</th>
    <th>Total</th>
    <th>Status</th>
    
    <th>Created</th>
    


   


   
   
  
    
</tr>   <?php /**PATH E:\amyapp\medonline\medonline\resources\views/components/Table/components/table_order_pharmacy.blade.php ENDPATH**/ ?>