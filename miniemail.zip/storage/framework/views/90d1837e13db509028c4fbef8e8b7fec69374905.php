<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
   <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'MedsOnline')); ?></title>
   <!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="loginfolder/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="loginfolder/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="loginfolder/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="loginfolder/fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="loginfolder/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="loginfolder/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="loginfolder/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="loginfolder/vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="loginfolder/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="loginfolder/css/util.css">
	<link rel="stylesheet" type="text/css" href="loginfolder/css/main.css?version='<?php echo e(env('APP_VERS')); ?>'">
<!--===============================================================================================-->
  <style>
	  #loading{
		  top:50%;
    }
    
    
	</style>
    
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img src="dashboard/assets/images/medsonlinelogo.png" alt="" >
                  <?php /*echo env('APP_NAME');*/?>
                        <!--<?php echo e(config('app.name', 'Supabitcoin')); ?>-->
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                 
                    
                          
                          
                        
                      
                    </ul>
                </div>
                <form class="form-inline">
                <?php if(Route::current()->getName()=='signuppage'): ?>
                <li class="nav-item">
              
              <a class="nav-link" href="signuppage">Register</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="signinpage">Login</a>
            </li>
            <?php elseif(Route::current()->getName()=='signinpage'): ?>
            <li class="nav-item">
              
              <a class="nav-link" href="signuppage">Register</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="signinpage">Login</a>
            </li>
            <?php elseif(Route::current()->getName()=='registerpage'): ?>
            <li class="nav-item">
              
              <a class="nav-link" href="registerpage">Register</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="loginpage">Login</a>
            </li>
            <?php elseif(Route::current()->getName()=='loginpage'): ?>

            <li class="nav-item">
              
              <a class="nav-link" href="registerpage">Register</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="loginpage">Login</a>
            </li>
            <?php else: ?>
            <li class="nav-item">
              
              <a class="nav-link" href="registerpage">Register</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="loginpage">Login</a>
            </li>
              <?php endif; ?>
              
  </form>
            </div>
            
        </nav>

        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Scripts -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script>
  $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
      $(".validate-form").submit(function(e) {
     
        $('.limiter').append(`<div class="cover-spin"></div>`);
    
 })

 function resend_email(encryptdata)
 {
  $('.limiter').append(`<div class="cover-spin"></div>`);
  $.ajax({
      
      url:'./resend_email',
      type:"post",
      
     data:{
    email:encryptdata,
    send_byajax:true,
    
   "_token":'<?php echo e(csrf_token()); ?>',
     },
      success:function(data)
      {
        //console.log(data);
    
  if(data.status)
  {
if(data.otp_confirm)//this is otp
{
//
$('.otp_append').attr('action', `${data.link}`);
  
  

					
  $('.divotp_append').html(`
  
     <input type="hidden" name="tel" value="${data.tel}">
<input type="hidden" name="expired_at" value="${data.expired_at}">
<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong></strong>Enter Your OTP
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
  <div class="wrap-input100 validate-input m-b-23" data-validate = "Username is required">
          <span class="label-input100">OTP</span>
          <input class="input100" type="text" name="otp" placeholder="otp">
          <span class="focus-input100" data-symbol="&#xf2be;"></span>
    <span class="help-block d-none"  style="color:red">
            <strong></strong>
          </span>
        </div>
        
          <div class="container-login100-form-btn">
          <div class="wrap-login100-form-btn">
            <div class="login100-form-bgbtn"></div>
            <button class="login100-form-btn">
              Verify
            </button>
          </div>
        </div>
  
  `);
  $('.cover-spin').remove();
//
}
else{//this is email sent
  alert("Email has been resend please Check your email");
$('.cover-spin').remove();

window.location.href =data.resend_page;

}


  }
  else{
    
    alert(`this email does not exist please Create one`);
    $('.cover-spin').remove();
  }



          
  
      
      } 
    });
 }
    
    </script>
</body>
</html>
<?php /**PATH E:\amyapp\medonline\medonline\resources\views/layouts/app.blade.php ENDPATH**/ ?>