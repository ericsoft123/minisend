<tr class="Client d-none">
<th>ID</th>
<th>OrderID</th>
<th>Total</th>
<th>Status</th>
<th>Pay Mode</th>
<th>Created_at</th>
<th>Action</th>
    
 </tr>   <?php /**PATH E:\amyapp\medonline\medonline\resources\views/components/Table/components/table_Medorder_client.blade.php ENDPATH**/ ?>