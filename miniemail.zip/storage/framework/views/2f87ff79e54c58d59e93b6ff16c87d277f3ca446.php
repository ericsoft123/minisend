<li class="app-sidebar__heading">DOCUMENTS</li>
                                <li  >
                                    <a href="#Forms_clientsubmit" class="mm-active" onclick="dynamic_menu('Forms_clientsubmit')" id="cashpayment_verification">
                                    <i class="metismenu-icon pe-7s-rocket"></i>
                                    Submit Documents
                                    </a>
                                </li>
                    
                                <li class="app-sidebar__heading">Schedule | Tracking</li>
                               
                               <li>
                                   <a href="#show_document" onclick="show_document();">
                                   <i class="metismenu-icon pe-7s-display2"></i>                   
                                  Documents
                                  <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>    
                                   </a>

                                   <ul class="listdoc_display">
                                     
                                       
                                      
  
                                   </ul>
                               </li>

                               <?php /**PATH E:\amyapp\medonline\medonline\resources\views/components/Menu/sideStandardUser.blade.php ENDPATH**/ ?>