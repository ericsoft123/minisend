
<?php $__env->startSection('content'); ?>

<div class="limiter">

		<div class="container-login100" style="background-image: url('loginfolder/images/bg-012.jpg');">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">
				<form class="login100-form validate-form" method="POST" action="<?php echo e(route('resend_email')); ?>">
				<?php echo e(csrf_field()); ?>

					
				<a href="index.html"><span style="visibility:hidden">Back Home</span></a><span class="login100-form-title p-b-49">
				Resend Email
				</span>
                <?php if(\Session::has('errors')): ?>
				<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Hi</strong><?php echo \Session::get('errors'); ?>

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php endif; ?>
					<?php if(\Session::has('status')): ?>
				<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong></strong><?php echo \Session::get('status'); ?>

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php endif; ?>
<?php if(\Session::has('encryptdata')): ?>
					<div class="wrap-input100 validate-input m-b-23 d-none" data-validate = "Username is required">
						<span class="label-input100">Email or Phone</span>
						<input class="input100" type="text" name="email" placeholder="Email or Phone" value="<?php echo e(\Session::get('encryptdata')); ?>">
						<span class="focus-input100" data-symbol="&#xf15a;"></span>
				
						<span class="help-block"  style="color:red">
							<strong></strong>
						</span>
                        
					</div>
                    <?php endif; ?>
					


					
					
                    <div class="text-right p-t-8 p-b-31" style="color:blue">
						
					</div>
					
					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn">
								Resend Email
							</button>
						</div>
					</div>
                    <div class="text-right p-t-8 p-b-31" >
						<a href="loginpage" style="color:blue">
						Login
						</a>
					</div>

					

				
				</form>
			</div>
		</div>
	</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\amyapp\medonline\medonline\resources\views//components/auth/users/resend.blade.php ENDPATH**/ ?>