     {data: 'id', name: 'id'},
               
     {data: 'product_name', name: 'product_name'},
     {data: 'price', name: 'price'},
     {data: 'delivery_price', name: 'delivery_price'},
     {data: 'total_price', name: 'total_price'},
     {data: 'status', name: 'status'},
     {data: 'created_at', name: 'created_at'},
     {data: 'action', name: 'action'},      
            
                                                   
                    
           
  
               
               
       
   <?php /**PATH E:\amyapp\medonline\medonline\resources\views/components/Table/jscomponents/table_order_Superjs.blade.php ENDPATH**/ ?>