<div class="au-card visible_div">
<h3 class="title-2 m-b-10 text-center docname"></h3>
<input type="hidden" class="tableid">
<hr>
<div class="table-responsive  m-b-40">
    <br>
   
                    <table id="Table_Paymenthistory"  class="table table-borderless table-data3" cellspacing="0" width="100%">
                         <thead>

                         <?php echo $__env->make('components.Table.components.table_Paymenthistory_pharmacy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                         <?php echo $__env->make('components.Table.components.table_Paymenthistory_Super', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                      </thead>
                        
                        
                    </table>
                </div>
                <hr>
                </div>
<?php /**PATH E:\amyapp\medonline\medonline\resources\views/components/Table/Table_Paymenthistory.blade.php ENDPATH**/ ?>