

<?php $__env->startSection('content'); ?>
  
<div id="app" >


<?php if(Auth::guard('Admin')->check()): ?>
<?php if(Auth::guard('Admin')->user()->platform==env('Super')): ?>
<admin-page></admin-page>
                                        
 <?php else: ?>

 <?php endif; ?>
 
 <?php elseif(Auth::check()): ?>
 <?php if(Auth::user()->platform==env('Client')): ?>
 <client-page></client-page>
   
  <?php else: ?>

  <?php endif; ?>  

 <?php else: ?>

 <?php endif; ?>                                          
                                                              



</div>
<!--app-display-->
  <!-- ======= Hero Section ======= -->
 

  
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Assessment test\miniemail\resources\views/profilepage.blade.php ENDPATH**/ ?>