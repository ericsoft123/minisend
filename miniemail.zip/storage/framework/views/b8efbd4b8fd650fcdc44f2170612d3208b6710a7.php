<ul class="vertical-nav-menu Super d-none">
<li class="app-sidebar__heading">Profile</li>
                            
                                <li>
                                    <a href="#Forms_UpdateProfile" onclick="dynamic_menu('Forms_UpdateProfile')">
                                    <i class="metismenu-icon pe-7s-display2"></i>                   
                                    Edit Profile
                                    </a>
                                </li>
                                


                                <li class="app-sidebar__heading">Orders</li>
                               
                                <li>
                                    <a href="#orders" >
                                    <i class="metismenu-icon pe-7s-display2"></i>                   
                                   View Order
                                   <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>    
                                    </a>

                                    <ul>
                                  
                                    <li>
                                    <a href="#Table_Medorders" onclick="dynamic_menu('Table_Medorders')">
                                              
                                                    <i class="metismenu-icon"></i>
                                                    Pending Orders
                                                </a>
                                            </li>
                                            <li>
                                            <a href="#Table_Prescorders" onclick="dynamic_menu('Table_Prescorders')">
                                                    <i class="metismenu-icon">
                                                    </i>Completed orders
                                                </a>
                                            </li>
                                            
                                         
                                          
                                          
                                            
                                        </ul>
                                </li>

                                <li class="app-sidebar__heading">Users</li>
                            
                            <li>
                                <a href="#Table_users" onclick="dynamic_menu('Table_users')">
                                <i class="metismenu-icon pe-7s-display2"></i>                   
                               View Users
                                </a>
                            </li> 
                            <li class="app-sidebar__heading">Pharmacy</li>
                            
                            <li>
                                <a href="#Table_admin" onclick="dynamic_menu('Table_admin')">
                                <i class="metismenu-icon pe-7s-display2"></i>                   
                                View Pharmacy
                                </a>
                            </li>    
                            <li class="app-sidebar__heading">Payments</li>
                            
                            <li>
                                <a href="#Table_Paymenthistory" onclick="dynamic_menu('Table_Paymenthistory')">
                                <i class="metismenu-icon pe-7s-display2"></i>                   
                                Billing Statement
                                </a>
                            </li>


                            <li class="app-sidebar__heading d-none">Flags Orders</li>
                               
                               <li class="d-none">
                                   <a href="#orders" >
                                   <i class="metismenu-icon pe-7s-display2"></i>                   
                                  View Reported Order
                                  <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>    
                                   </a>

                                   <ul>
                                           <li>
                                               <a href="#Table_Prescorders" onclick="dynamic_menu('Table_Prescorders')">
                                                   <i class="metismenu-icon"></i>
                                                   Client
                                               </a>
                                           </li>
                                           <li>
                                               <a href="#Table_Medorders" onclick="dynamic_menu('Table_Medorders')">
                                                   <i class="metismenu-icon">
                                                   </i>Pharmacy
                                               </a>
                                           </li>
                                           
                                        
                                         
                                         
                                           
                                       </ul>
                               </li>
                                <li class="app-sidebar__heading d-none" >Settings</li>
                                
                                <li class="d-none">
                                    <a href="#show_document " onclick="show_document();">
                                    <i class="metismenu-icon pe-7s-display2 d-none"></i>      
                                    Settings
                                    <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>                   
                                    </a>

                                    <ul class="listinvoice_display">
                                        
                                        
                                       
   
                                    </ul>
                                </li>

              

                                <li class="app-sidebar__heading d-none" >Invoice</li>
                                
                                <li class="d-none">
                                    <a href="#show_document" onclick="show_document();">
                                    <i class="metismenu-icon pe-7s-display2"></i>      
                                    Customize Invoice
                                    <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>                   
                                    </a>

                                    <ul class="listinvoice_display">
                                        
                                        
                                       
   
                                    </ul>
                                </li>
                                </ul><?php /**PATH E:\Assessment test\miniemail\resources\views/components/Menu/sideSuperUser.blade.php ENDPATH**/ ?>