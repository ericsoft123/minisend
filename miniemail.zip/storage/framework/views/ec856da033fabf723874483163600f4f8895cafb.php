<tr class="Super d-none">
    <th>ID</th>
    <th>Name</th>
    <th>Email</th>
    
    <th>Tel</th>
    <th>Status</th>
    <th>Address</th>
    <th>Created_at</th>
    
    <th>Action</th>


   
   
  
    
</tr> <?php /**PATH E:\amyapp\medonline\medonline\resources\views/components/Table/components/table_user_Super.blade.php ENDPATH**/ ?>