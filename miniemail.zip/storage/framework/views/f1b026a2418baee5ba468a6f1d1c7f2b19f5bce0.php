{data: 'DT_RowIndex',name:'DT_RowIndex'},
     {data:'uid',name:'uid'},
    
    
     {data: 'created_at', name: 'created_at'},
     {data: 'updated_at', name: 'updated_at'},
     {data: 'price', name: 'price'},
  
     {data: 'created_at', name: 'Created_at'},
     <?php /**PATH E:\amyapp\medonline\medonline\resources\views/components/Table/jscomponents/table_Paymenthistory_pharmacyjs.blade.php ENDPATH**/ ?>