<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
   <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(env('APP_NAME')); ?></title>
   <!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="loginfolder/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="loginfolder/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="loginfolder/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="loginfolder/fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="loginfolder/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="loginfolder/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="loginfolder/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="loginfolder/vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="loginfolder/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="loginfolder/css/util.css">

  <link href="css/mycss.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="loginfolder/css/main.css?version='<?php echo e(env('APP_VERS')); ?>'">
<!--===============================================================================================-->
  <style>
	  #loading{
		  top:50%;
    }
    
    
	</style>
    
</head>
<body>
    <div id="app">
    
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <!-- Branding Image -->
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img src="images/logo.png" alt="" >
                  <?php /*echo env('APP_NAME');*/?>
                        <!--<?php echo e(config('app.name', 'Supabitcoin')); ?>-->
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                 
                    
                          
                          
                        
                      
                    </ul>
                </div>
                <form class="form-inline">
              
                <?php if(Auth::guard('Admin')->check()): ?>

                <li class="nav-item">
              
              <a class="nav-link" href="#"><i class="fa fa-user" aria-hidden="true"></i> <?php echo e(Auth::guard('Admin')->user()->name); ?></a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="logout"><i class="fa fa-power-off text-danger" aria-hidden="true"></i> Logout</a>
            </li>
            <?php elseif(Auth::check()): ?>
                <li class="nav-item">
              
              <a class="nav-link" href="#"><i class="fa fa-user" aria-hidden="true"></i> <?php echo e(Auth::user()->name); ?></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="logout"><i class="fa fa-power-off text-danger" aria-hidden="true"></i> Logout</a>
            </li>
            <?php else: ?>
            <li class="nav-item">
              
              <a class="nav-link" href="registerpage">Register</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="loginpage">Login</a>
            </li>

                <?php endif; ?>
                
              
  </form>
            </div>
            
        </nav>

        <?php echo $__env->yieldContent('content'); ?>
    </div>
  <!-- Vendor JS Files -->
  <script src="<?php echo e(mix('js/app.js')); ?>"></script>
    <!-- Scripts -->
  
</body>
</html>
<?php /**PATH E:\Assessment test\miniemail\resources\views/layouts/app.blade.php ENDPATH**/ ?>