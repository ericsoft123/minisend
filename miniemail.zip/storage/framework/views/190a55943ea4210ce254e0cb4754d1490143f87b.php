<tr class="Super d-none">
<th>ID</th>
    <th>InvoiceID</th>
    <th>UserID</th>
   
    <th>Paid From</th>
    <th>Paid To</th>
    <th>Price</th>
    <th>Activated By</th>
    <th>Created_at</th>
    
</tr> <?php /**PATH E:\amyapp\medonline\medonline\resources\views/components/Table/components/table_Paymenthistory_Super.blade.php ENDPATH**/ ?>