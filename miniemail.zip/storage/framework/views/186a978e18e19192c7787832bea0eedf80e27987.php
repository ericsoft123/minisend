<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>APP|Medonline</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <!--<link href="home/assets/img/favicon.png" rel="icon">-->
  <link href="home/assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->

<link href="home/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
 
  <!-- Template Main CSS File -->
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
  <link href="home/assets/css/mycss.css" rel="stylesheet">
  <!--<link href="home/assets/css/style.css" rel="stylesheet">-->

  <!-- =======================================================
  * Template Name: eNno - v2.0.0
  * Template URL: https://bootstrapmade.com/enno-free-simple-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  
<div id="app" >

<front-page></front-page>
<search-page></search-page>

</div>
<!--app-display-->
  <!-- ======= Hero Section ======= -->
 
  <!-- Vendor JS Files -->
  <script src="<?php echo e(mix('js/app.js')); ?>"></script>
  
  

</body>

</html><?php /**PATH E:\Assessment test\miniemail\resources\views/homepage.blade.php ENDPATH**/ ?>