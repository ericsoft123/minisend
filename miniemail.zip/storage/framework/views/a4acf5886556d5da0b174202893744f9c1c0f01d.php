<script>
var mainmethod={

    <?php echo $__env->make('components.Table.Table_Medordersjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.Table.Table_Prescordersjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('components.Table.Table_usersjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.Table.Table_adminjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
   
    <?php echo $__env->make('components.Table.Table_Paymenthistoryjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    Forms_UserMedecine:function(){
    use_location();
    get_profile_detail();
//search_address_profile();
$('.change_area').addClass('d-none');
setTimeout(() => {
  search_address_profile();
}, 1000);
  },
  Forms_UploadPrescription:function(){
    use_location();
    get_profile_detail();
    $('.change_area').addClass('d-none');
    //search_address_profile();
    setTimeout(() => {
  search_address_profile();
}, 1000);
},
Forms_UpdateProfile:function(){
    use_location();
    get_profile_detail();
    //search_address_profile();
},

}


</script>
<?php echo $__env->make('components.Sharejs.Sharejs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\amyapp\medonline\medonline\resources\views/components/Mainjs/mainjs.blade.php ENDPATH**/ ?>