
 //table   
Table_Paymenthistory:function(){
     //
     oTable = $('#Table_Paymenthistory').DataTable({
           "processing": false,
           "serverSide": true,
               "destroy":true,
               "responsive": true,
                ajax: {
       url:"<?php echo e(route('table_payment_history')); ?>",
        type:"post",
        data:{
         
          "_token":'<?php echo e(csrf_token()); ?>'
        }
        
         
    },"columns": [

//data




<?php if(Auth::guard('Admin')->check()): ?>
                                      <?php if(Auth::guard('Admin')->user()->platform==env('Standard')): ?>
                                      <?php echo $__env->make('components.Table.jscomponents.table_Paymenthistory_pharmacyjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        
                                       <?php else: ?>
                                       <?php echo $__env->make('components.Table.jscomponents.table_Paymenthistory_Superjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                       <?php endif; ?>
 
                                      <?php elseif(Auth::check()): ?>
                                      <?php if(Auth::user()->platform==env('Client')): ?>
                                    
                                        
                                       <?php else: ?>
                                     <div>none</div>   
                                       <?php endif; ?>  
                                     
                                      <?php else: ?>
  
                                      <?php endif; ?>
                                     

//data


    
    ],
       
       
                   
      });

     new $.fn.dataTable.FixedHeader( oTable );
//

} ,  
  
  //table<?php /**PATH E:\Assessment test\miniemail\resources\views/components/Table/Table_Paymenthistoryjs.blade.php ENDPATH**/ ?>