<div class="col-xl-6">
 <!--new orders-->
   <!--Recent Orders-->
   <div class="main-card mb-3 card">

                         
           
<div class="card-body card-body-myform"><h5 class="card-title">Recent Requested Orders</h5>

<table class=" table table-xs table_green table-bordered ">

<tr>
<!--<th></th>-->
<th >#</th>
<th >OrderId</th>
<th >Total</th>
<th >Created At</th>
</tr>
<?php 


$chatrequest=DB::select("select uid,total_pricing,created_at from chatrequests $createria_request  GROUP by uid order by id  desc limit 5");
$i=1;
foreach($chatrequest as $row)
{
?>
<tr class="item-row">
<td  title="#"><?php echo $i; ?></td>
<td  title="OrderId"><?php echo $row->uid; ?></td>
<td  title="Total">R <?php echo $row->total_pricing; ?></td>
<td title="Created At"><?php echo $row->created_at; ?></td>
</tr>

<?php
$i++;
}

?>



</table>





</div>
</div>
 <!--new orders-->


</div>
<div class="col-xl-6">
         <!--Rejected orders-->
         <div class="main-card mb-3 card">
                                    <div class="card-body card-body-myform "><h5 class="card-title">Recent Rejected Orders</h5>
                                        <table class="table table-xs table_blue table_rejected">
           
                                        <tr>
      <!--<th></th>-->
      <th >#</th>
      <th >OrderId</th>
      <th >Total</th>
      <th >Created At</th>
    </tr>
    <?php 
  
  
    $chatrequest=DB::select("select uid,total_pricing,created_at from reject_requests $createria_request GROUP by uid order by id desc limit 5");
    $i=1;
foreach($chatrequest as $row)
{
    ?>
    <tr class="item-row">
    <td  title="#"><?php echo $i; ?></td>
    <td  title="OrderId"><?php echo $row->uid; ?></td>
    <td  title="Total">R <?php echo $row->total_pricing; ?></td>
    <td title="Created At"><?php echo $row->created_at; ?></td>
    </tr>

<?php
$i++;
}

?>
           
           
                                    </table>
                                    </div>
                                </div>
                                <!--Rejected orders-->
</div>
<?php /**PATH E:\amyapp\medonline\medonline\resources\views/components/Forms/Forms_Table_history_home.blade.php ENDPATH**/ ?>