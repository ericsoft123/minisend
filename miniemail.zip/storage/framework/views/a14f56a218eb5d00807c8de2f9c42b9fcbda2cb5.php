
 //table   
Table_users:function(){
     //
     oTable = $('#Table_users').DataTable({
           "processing": false,
           "serverSide": true,
               "destroy":true,
               "responsive": true,
                ajax: {
       url:"<?php echo e(route('table_users')); ?>",
        type:"post",
        data:{
          "_token":'<?php echo e(csrf_token()); ?>'
        }
        
         
    },"columns": [

//data




<?php echo $__env->make('components.Table.jscomponents.table_user_Superjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                     

//data


    
    ],
       
       
                   
      });

     new $.fn.dataTable.FixedHeader( oTable );
//

} ,   
  
  //table<?php /**PATH E:\amyapp\medonline\medonline\resources\views/components/Table/Table_usersjs.blade.php ENDPATH**/ ?>