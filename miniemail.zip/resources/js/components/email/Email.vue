<template>
    <div class="container">
      <div class="container">
  <div class="row">
    <div class="col-sm">
      Posted
    </div>
    <div class="col-sm">
      Sent
    </div>
    <div class="col-sm">
     Failed 
    </div>
  </div>
</div>
<div class="col-md">
    <input type="text" class="form-control" v-model="message" @input="myChangeFunction(this)">
</div>
<div class="container">
<div  v-bind:key="email_item.id" v-for="email_item in email_data">

<h1>{{email_item.recipient}}</h1>

</div>
</div>


    </div>
</template>
<script>
import Search from './Search';
export default {
    data:function(){
        return{
             email_data:[],
             message: ''
        }
    },
    mounted(){
this.loademail();
    },
    methods:{
        loademail(){
            //load Api and assign to email_data
            //axios.get('./loademail')
       
    try {
               
   axios.get('/loads_email').then((response) => {

          
      this.email_data=response.data.result;

      //console.log(response.data.result.length);
        });



       
    } catch (error) {
        console.log(error);
    }
    //
            
        },
        myChangeFunction(thisdata){
            console.log(this.message);
        }

    }
}
</script>