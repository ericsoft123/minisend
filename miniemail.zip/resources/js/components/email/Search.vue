<template>
    <div> {{message}}</div>
</template>

<script>
export default {
    name:"Search",
props:["message"],
components:{

}
}
</script>

