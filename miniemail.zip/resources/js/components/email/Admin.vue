<template>
<div class="container pt-4">
 <div class="cover-spin"  v-if="spin_show2"></div>
   <div class="row">
       <div class="col-md-4">

<ul class="list-group" v-for="(message,index) in message_counterdata" :key="index">
    <li class="list-group-item d-flex justify-content-between align-items-center" @click="admin_User()">
    Total Clients by Country
    <span class="badge badge-primary badge-pill">{{user_count}}</span>
  </li>
<li class="list-group-item d-flex justify-content-between align-items-center activex" >
    Total Posted 
    
<span class="badge badge-primary badge-pill">{{message.posted_email}}</span>
  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center" >
   Total  Sent
    <span class="badge badge-primary badge-pill">{{message.sent_email}}</span>
  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center" >
    Total Failed
    <span class="badge badge-primary badge-pill">{{message.failed_email}}</span>
  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center" @click="admin_view_clients()">
    View Clients
    <span class="badge badge-primary badge-pill"></span>
  </li>

   
</ul>


<div class="pt-2">
    <h3 class="text-center">{{clientName}}</h3>
    <ul class="list-group" >
<li class="list-group-item d-flex justify-content-between align-items-center activex">
 Posted 
    
<span class="badge badge-primary badge-pill">{{message_clientdata.posted_emails}}</span>
  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center" >
   Sent
    <span class="badge badge-primary badge-pill">{{message_clientdata.sent_emails}}</span>
  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center" >
    Failed
    <span class="badge badge-primary badge-pill">{{message_clientdata.failed_emails}}</span>
  </li>

</ul>
</div>
           
       </div>

       <div class="col-md">
           <!--search Input-->
<div class="col-md" v-if="search_show">
    <input type="text" class="form-control" v-model="search_input_data" @input="SearchAction()">
<div class="list-group pt-1 mylist_search" v-bind:key="email_item.id" v-for="email_item in email_data">

  <a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
    <div class="d-flex w-100 justify-content-between">
      <h5 class="mb-1">From {{email_item.subject}}</h5>
      <small class="text-muted"><i :class="[email_item.att_url!='none'?'':'d-none','fa fa-paperclip']"></i></small>
    </div>
    <p class="mb-1">To:{{email_item.subject}}</p>
    <small class="text-muted">Donec id elit non mi porta.</small>
  </a>

</div>

</div>
           <!--search Input-->
<!--table clients-->
<div class="col-md pt-2"  v-if="table_show">

 <table class="table table-inbox table-hover">
     <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Country</th>
      <th scope="col">Created At</th>
    </tr>
  </thead>
          <tbody v-bind:key="email_item.id" v-for="email_item in email_data">
            <tr class="unread" @click="View_client(`${email_item.table_uid}`,`${email_item.name}`,`${email_item.userid}`)">
              
              <td class="inbox-small-cells"><i class="fa fa-star"></i></td>
              <td class="view-message  dont-show">{{email_item.name}}</td>
              <td class="view-message ">{{email_item.email}}</td>
              <td class="view-message  inbox-small-cells">{{email_item.country}}</td>
            
              <td class="view-message  text-right">{{email_item.created_at}} AM</td>
            </tr>
            
        
          </tbody>
        </table>
    </div>
<!--table clients-->

<!--table partition-->
 <table class="table table-inbox table-hover">
      <thead>
    <tr>
     
      <th scope="col">table ID</th>
      <th scope="col">Country Code</th>
      <th scope="col">Country</th>
      <th scope="col">Total</th>
    </tr>
  </thead>
          <tbody v-bind:key="user_item.id" v-for="user_item in user_data">
            <tr class="unread" >
              
             
              <td class="view-message  dont-show">{{user_item.table_uid}}</td>
              <td class="view-message ">{{user_item.country_code}}</td>
              <td class="view-message  inbox-small-cells">{{user_item.country}}</td>
            
              <td class="view-message  text-right">{{user_item.total}}</td>
            </tr>
            
        
          </tbody>
        </table>
<!--table partition-->





       </div>



   </div>
</div>
</template>

<script>
import Search from './Search';


export default {
    data:function(){
        return{
             email_data:[],
             user_data:[],
             search_input_data: '',
             ActionName:'default',
         
            
              table_show:true,
              view_email:false,
              search_show:true,
     
             
              count_hide:'',
              email_view:'',
              email_view_show:false,
              message_counterdata:'',
                spin_show2:true,
                user_count:'',
                clientName:'',
                message_clientdata:{},
                
            
        }
    },
    mounted(){
    this.spin_show2=false;
     this.admin_count_all();
    },
    methods:{
      admin_count_all(){

     try {
               
   axios.get('/admin_count_all').then((response) => {

          
      //this.email_data=response.data.result;
      if(response.data.status)
      {
       
        this.message_counterdata=response.data.result.message_counter;
        this.user_count=response.data.result.user_counter;
      }
    

        });



       
    } catch (error) {
        console.log(error);
    }

      },

         admin_view_clients(){
              try {
               
   axios.get('/admin_view_clients').then((response) => {

          
    
      if(response.data.status)
      {
      
this.email_data=response.data.result;
console.log(response.data.result);
      }
    

      
        });



       
    } catch (error) {
        console.log(error);
    }

      },
      View_client(table_uid,name,userid){
         try {
               
   axios.get('/admin_count_user', {
    params: {
      table_uid:table_uid,
      userid:userid
    }
  }).then((response) => {

          
      //this.email_data=response.data.result;
      if(response.data.status)
      {
       // console.log(response.data.result);
 this.clientName=name;
 this.message_clientdata=response.data.result;
      }
    

      //console.log(response.data.result.length);
        });



       
    } catch (error) {
        console.log(error);
    }
      },
           admin_count_user(){
              try {
               
   axios.get('/admin_count_user').then((response) => {

          
      //this.email_data=response.data.result;
      if(response.data.status)
      {
       // console.log(response.data.result);
  this.post_email_count=response.data.result.posted_emails;
      this.sent_email_count=response.data.result.sent_emails;
      this.failed_email_count=response.data.result.failed_emails;
      }
    

      //console.log(response.data.result.length);
        });



       
    } catch (error) {
        console.log(error);
    }

      },
    admin_User(){
              try {
               
   axios.get('/admin_view_user').then((response) => {

          
      //this.email_data=response.data.result;
      if(response.data.status)
      {
       // console.log(response.data.result);
  this.user_data=response.data.result;
      }
    

      //console.log(response.data.result.length);
        });



       
    } catch (error) {
        console.log(error);
    }

      }
    
    }
     
    
}
</script>