<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use DB;

class ProfileController extends Controller
{

    
    public function __construct()
    {
        date_default_timezone_set(env('TIME_ZONE'));
        $this->today = date('Y-m-d H:i:s', time());
       $this->creator=env('Super');
       $this->limit_distance=env('LIMIT_DISTANCE');
  
        
    }
    public function profile(){
        if(Auth::check()){
            return view('Profilepage');
        }
        else if(Auth::guard('Admin')->check()){
            return view('profilepage');
        }
        else{
            return view('homepage');
            //echo'you are not signup';
        }

        
    }

    public function get_componentblade(Request $request){
        
      
    if(Auth::check())
    {
      //
        //$mytemplate="form_creator"; 
        $mytemplate=$request->get('hashdata'); 
        $locationfolder=$request->get('locationfolder'); 
        $menu="components.$locationfolder.".$mytemplate;
        //$javasciptdata="components.$locationfolder.".$mytemplate."js";
        $locationfolder1="Mainjs";
        $mytemplate1="main";
        $javasciptdata="components.$locationfolder1.".$mytemplate1."js";
        
       return response()->json([
        'status'=>true,
        'divdata' => view($menu)->render(),
        'javascriptdata' => view($javasciptdata)->render(),
       'platform'=>Auth::user()->platform,
       'userid'=>Auth::user()->userid,
    ]);
      //
    }
    else if(Auth::guard('Admin')->check()){


         //
        //$mytemplate="form_creator"; 
        $mytemplate=$request->get('hashdata'); 
        $locationfolder=$request->get('locationfolder'); 
        $menu="components.$locationfolder.".$mytemplate;
        //$javasciptdata="components.$locationfolder.".$mytemplate."js";
        $locationfolder1="Mainjs";
        $mytemplate1="main";
        $javasciptdata="components.$locationfolder1.".$mytemplate1."js";
        
       return response()->json([
        'status'=>true,
        'divdata' => view($menu)->render(),
        'javascriptdata' => view($javasciptdata)->render(),
        'platform'=>Auth::guard('Admin')->user()->platform,
        'userid'=>Auth::guard('Admin')->user()->userid,
    ]);
      //
      
    }
    else{
        return response([
            "status"=>false,
            "error"=>"1",//unauthorized or expired
                ],201);
    }
    
    }
    public function search_address_profile(Request $request){

       
        if($request->get('mylat')!=0)
        {
            $user_lat=$request->get('mylat');
            $user_lng=$request->get('mylng');
            $search_limit=$request->get('search_limit')?:$this->limit_distance;
           //
           $check=DB::select("SELECT * FROM (
            SELECT *, 
                (
                    (
                        (
                            acos(
                                sin(( $user_lat * pi() / 180))
                                *
                                sin(( `lat` * pi() / 180)) + cos(($user_lat * pi() /180 ))
                                *
                                cos(( `lat` * pi() / 180)) * cos((( $user_lng - `lng`) * pi()/180)))
                        ) * 180/pi()
                    ) * 60 * 1.1515
                )
            as distance FROM `admins`
        ) myTable
        
        WHERE distance <=$search_limit
        LIMIT 5");
    
    //WHERE distance <=$this->limit_distance
            if($check)
            {
                return response()->json([
                    "status"=>true,
                    "result"=>$check,
                    "error_message_selector"=>'error_message',
                        ],200);
            }
            else{
                return response()->json([
                    "status"=>false,
                    "error_message_selector"=>'error_message',
                        ],201);
            }
            
           //
          
        }
        else{
            $user_lat=Auth::user()->lat;
            $user_lng=Auth::user()->lng;

            //
            $check=DB::select("SELECT * FROM (
                SELECT *, 
                    (
                        (
                            (
                                acos(
                                    sin(( $user_lat * pi() / 180))
                                    *
                                    sin(( `lat` * pi() / 180)) + cos(($user_lat * pi() /180 ))
                                    *
                                    cos(( `lat` * pi() / 180)) * cos((( $user_lng - `lng`) * pi()/180)))
                            ) * 180/pi()
                        ) * 60 * 1.1515
                    )
                as distance FROM `admins`
            ) myTable
            
            WHERE distance <=$this->limit_distance
            LIMIT 5");
        
        //WHERE distance <=$this->limit_distance
                if($check)
                {
                    return response()->json([
                        "status"=>true,
                        "result"=>$check,
                            ],200);
                }
                else{
                    return response()->json([
                        "status"=>false,
                        "error_message_selector"=>'error_message',
                            ],201);
                }
                
            //
            
        }
        //note this down query is working too
        //note name will be replaced on pharmarcie name on production
      //  $check=DB::select("SELECT userid as uid_provider,name as pharmacie_name,phys_address as pharmacie_location,id, ( 3959 * acos( cos( radians($user_lat) ) * cos( radians( lat ) ) * cos( radians( lng ) - radians($user_lng) ) + sin( radians($user_lat) ) * sin( radians( lat ) ) ) ) AS distance FROM admins HAVING distance < $this->limit_distance ORDER BY distance LIMIT 0 , 20");
      
     
      
     
    }
    public function report_profile(Request $request){
        $reported_uid=$request->input('reported_uid');
        $description=$request->input('description');
        if(Auth::check())
        {
           return $this->User_report_admin($reported_uid,$description);
        }
        else if(Auth::guard('Admin')->check()){
            return $this->Admin_report_user($reported_uid,$description);
        }
        else{
            return response([
                "result"=>false,
                "error"=>"1",//unauthorized or expired
                    ],201);
        }
    }
    public function User_report_admin($reported_uid,$description){
        $userid=Auth::user()->userid;
           
        $uid='report'.""."_".date(time());
        $check=DB::table("reportusers")
    
        ->insert([
            
           'uid'=>$uid,
            'userid'=>$userid,
            'reported_uid'=>$reported_uid,
            'description'=>$description,//comment
          
            "created_at"=>$this->today,
        ]);
        if($check)
        {
            return response([
        "result"=>true,
            ],200);
        }
        else{
            return response([
                "result"=>false,
                "error"=>"0",
                    ],201);
        }
    }
    public function Admin_report_user($reported_uid,$description){
        $userid=Auth::guard('Admin')->user()->userid;
           
        $uid='report'.""."_".date(time());
        $check=DB::table("reportadmins")
    
        ->insert([
            
           'uid'=>$uid,
            'userid'=>$userid,
            'reported_uid'=>$reported_uid,
            'description'=>$description,

            "created_at"=>$this->today,
        ]);
        if($check)
        {
            return response([
        "result"=>true,
            ],200);
        }
        else{
            return response([
                "result"=>false,
                "error"=>"0",
                    ],201);
        }
    }
    public function get_profile_detail(){
     
      
    if(Auth::check())
      {
return $this->User_profile_detail();

      }
      else if(Auth::guard('Admin')->check()){
return $this->Admin_profile_detail();
      }
      else{
        return response([
            "result"=>false,
            "error"=>"0",
                ],201);
    }
    }
    public function User_profile_detail(){

       
        
  
$users=array(
    
        "userid"=>Auth::user()->userid,
        "email"=>Auth::user()->email,
        "name"=>Auth::user()->name,
        "fname"=>Auth::user()->fname,
        "lname"=>Auth::user()->lname,
        "password"=>Auth::user()->passdecode,
        "tel"=>Auth::user()->tel,
        "platform"=>Auth::user()->platform,
        "platform_menu"=>[
            "menu_hide"=>"d-none",
         "platform"=>Auth::user()->platform
        ],
        "phys_address"=>Auth::user()->phys_address,
        "lat"=>Auth::user()->lat,
        "lng"=>Auth::user()->lng,
        "dob"=>Auth::user()->dob,
        "audio"=>Auth::user()->audio,
        "audio_setting"=>Auth::user()->audio_setting,
        "gender"=>Auth::user()->gender,
        "id_number"=>Auth::user()->id_number,
        "martial_status"=>Auth::user()->martial_status,
        "title"=>Auth::user()->title,
    
    
        
    
);

return response([
    "result"=>true,
    "response"=>$users
        ],200);
     
    
}
public function Admin_profile_detail(){
    $users=array(
    
        "userid"=>Auth::guard('Admin')->user()->userid,
        "email"=>Auth::guard('Admin')->user()->email,
        "name"=>Auth::guard('Admin')->user()->name,
        "fname"=>Auth::guard('Admin')->user()->fname,
        "lname"=>Auth::guard('Admin')->user()->lname,
        "password"=>Auth::guard('Admin')->user()->passdecode,
        "tel"=>Auth::guard('Admin')->user()->tel,
        "platform"=>Auth::guard('Admin')->user()->platform,
        "platform_menu"=>[
            "menu_hide"=>"d-none",
            "platform"=>Auth::guard('Admin')->user()->platform,
           ],
        "phys_address"=>Auth::guard('Admin')->user()->phys_address,
        "postal_address"=>Auth::guard('Admin')->user()->postal_address,
        "y_number"=>Auth::guard('Admin')->user()->y_number,
        "p_number"=>Auth::guard('Admin')->user()->p_number,
        "lat"=>Auth::guard('Admin')->user()->lat,
        "lng"=>Auth::guard('Admin')->user()->lng,
        "audio"=>Auth::guard('Admin')->user()->audio,
        "audio_setting"=>Auth::guard('Admin')->user()->audio_setting,
        "alternative_no"=>Auth::guard('Admin')->user()->alternative_no,
        "updated_at"=>Auth::guard('Admin')->user()->updated_at,
      
    
);

return response([
    "result"=>true,
    "response"=>$users
        ],200);
}
    //
public function change_audio_profile(Request $request)
{
    $audio=$request->input('audio');
    $audio_save_db=$request->input('audio_save_db');
    if(Auth::check())
    {
        return $this->User_audio_profile($audio,$audio_save_db);  
    }
    else if(Auth::guard('Admin')->check())
    {
        return $this->Admin_audio_profile($audio,$audio_save_db);
    }
    else{
        return response([
            "status"=>false,
            "error"=>"1",//unauthorized or expired
                ],201);
    }
}
public function User_audio_profile($audio,$audio_save_db)
{
      
    $userid=Auth::user()->userid;
           
       
    $check=DB::table("users")
    ->where('userid',$userid)
   
    ->update([
        'audio'=>$audio,
        'audio_setting'=>$audio_save_db,
        
        //"updated_at"=>$this->today,
    ]);
    if($check)
    {
        //return redirect()->route('profile');//testing purpose only
        return response([
    "status"=>true,
        ],200);
    }
    else{
        return response([
            "status"=>false,
            "error"=>"0",
                ],201);
    }

}
public function Admin_audio_profile($audio,$audio_save_db)
{
    $userid=Auth::guard('Admin')->user()->userid;
       
    $check=DB::table("admins")
    ->where('userid',$userid)
   
    ->update([
        'audio'=>$audio,
        'audio_setting'=>$audio_save_db,
        
        //"updated_at"=>$this->today,
    ]);
    if($check)
    {
        //return redirect()->route('profile');//testing purpose only
        return response([
    "status"=>true,
        ],200);
    }
    else{
        return response([
            "status"=>false,
            "error"=>"0",
                ],201);
    }
    
}
    public function change_profile(Request $request){
        //$platform=Auth::user()->platform;
        $fname=$request->input('fname');
        $lname=$request->input('lname');
        $name=$request->input('name');
        $updated_at=$request->input('updated_at');
        $email=$request->input('email'); 
        $password=$request->input('password');
        $tel=$request->input('tel');
        $phys_address=$request->input('phys_address');
        $dynamic_address=$request->input('dynamic_address');
        
        $postal_address=$request->input('postal_address')?:'none';
        $y_number=$request->input('y_number')?:'none';
        $alternative_no=$request->input('alternative_no')?:'none';
        $p_number=$request->input('p_number')?:'none';
        $dob=$request->input('dob')?:'none';
        $gender=$request->input('gender')?:'none';
        $id_number=$request->input('id_number')?:'none';
        $marital_status=$request->input('marital_status')?:'none';
        $title=$request->input('title')?:'none';
       // $=$request->input('')?:'none';
       
        $lat=$request->input('lat');
        $lng=$request->input('lng');
        

        if(Auth::check())
        {
            return $this->User_change_profile($name,$fname,$lname,$email,$tel,$password,$phys_address,$dynamic_address,$lat,$lng,$postal_address,$y_number,$alternative_no,$p_number,$dob,$gender,$id_number,$marital_status,$title);  
        }
        else if(Auth::guard('Admin')->check())
        {
            return $this->Admin_change_profile($name,$fname,$lname,$email,$tel,$password,$phys_address,$dynamic_address,$lat,$lng,$postal_address,$y_number,$alternative_no,$p_number,$dob,$gender,$id_number,$marital_status,$title,$updated_at); 
        }
        else{
            return response([
                "status"=>false,
                "error"=>"1",//unauthorized or expired
                    ],201);
        }
    }

public function c(){//not yet finished
    $myemail=$email==Auth::user()->email?true:false;      
    $mytel=$tel==Auth::user()->tel?true:false; 
   
   
    
    if($myemail&&$mytel)
    {
        return response([
            "status"=>true,
            ],200);
    }
    else
    {
       
        $users=DB::select("select tel,email *from users where tel='$mytel' or email= limit 1");

      
        
    }
   
}
public function  User_change_profile($name,$fname,$lname,$email,$tel,$password,$phys_address,$dynamic_address,$lat,$lng,$postal_address,$y_number,$alternative_no,$p_number,$dob,$gender,$id_number,$marital_status,$title){
  
    $userid=Auth::user()->userid;
  
       
    $check=DB::table("users")
    ->where('userid',$userid)
   
    ->update([
        
       
        'fname'=>$fname,
        'lname'=>$lname,
        'name'=>$fname." ".$lname,
        'email'=>$email,
        'tel'=>$tel,
        'password'=>bcrypt($password),
        'passdecode'=>$password,
       'phys_address'=>$phys_address,
       //new
       'dob'=>$dob,
       'gender'=>$gender,
       'id_number'=>$id_number,
       'marital_status'=>$marital_status,
       'title'=>$title,
       // 'dynamic_address'=>$dynamic_address,
        'lat'=>$lat,
        'lng'=>$lng,
        //"updated_at"=>$this->today,
    ]);
    if($check)
    {
        //return redirect()->route('profile');//testing purpose only
        return response([
    "status"=>true,
        ],200);
    }
    else{
        return response([
            "status"=>false,
            "error"=>"0",
                ],201);
    }
}
    public function Admin_change_profile($name,$fname,$lname,$email,$tel,$password,$phys_address,$dynamic_address,$lat,$lng,$postal_address,$y_number,$alternative_no,$p_number,$dob,$gender,$id_number,$marital_status,$title,$updated_at){
        //$platform=Auth::user()->platform;

        $userid=Auth::guard('Admin')->user()->userid;
           
       
    $check=DB::table("admins")
    ->where('userid',$userid)
   
    ->update([
        //pharmacy
      
        'name'=>$name,
        'tel'=>$tel,
        'email'=>$email,
        'password'=>bcrypt($password),
        'passdecode'=>$password,
       'phys_address'=>$phys_address,
       'postal_address'=>$postal_address,
       'y_number'=>$y_number,
       
       'lat'=>$lat,
        'lng'=>$lng,
       
        'fname'=>$fname,
        'lname'=>$lname,
        'alternative_no'=>$alternative_no,
        'p_number'=>$p_number,
        //"updated_at"=>$this->today,
    ]);
    if($check)
    {
        //return redirect()->route('profile');//testing purpose only
        return response([
    "status"=>true,
        ],200);
    }
    else{
        return response([
            "status"=>false,
            "error"=>"0",
                ],201);
    }


    }
    
}
