<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Auth;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Mail;

class TestController extends Controller
{
    public function __construct()
    {
        $this->Appstate=env('APP_LIVE')?env('APP_PRO'):env('APP_DEV');
        date_default_timezone_set(env('TIME_ZONE'));
        $this->today = date('Y-m-d H:i:s', time());
        $this->mydate_format="Y-m-d H:i:s";
        $this->mysettings=env('APP_LIVE')?$this->production():$this->dev();
    }
    public function dev(){//development settings
        $settings = array( 
            "checkreqtime" =>date($this->mydate_format,strtotime("5 Minutes", strtotime($this->today))), 
            "pharmacytime" =>date($this->mydate_format,strtotime("5 Minutes", strtotime($this->today))), 
            
        ); 
       return $setting=json_encode($settings);
    }
    public function production()//this is production settings
    {
        $settings = array( 
            "checkreqtime" =>date($this->mydate_format,strtotime("1 Hours", strtotime($this->today))), 
            "pharmacytime" =>date($this->mydate_format,strtotime("1 Hours", strtotime($this->today))), 
            "status"=>'test'
            
        ); 
       return $settings=json_encode($settings);
      
    }
    //crud
public function test_function(){
return $this->production();
}
public function test_check(){
    
   return $this->email_inbox();

}

public function detect_country(){
       //php curl
     // create & initialize a curl session
 $curl = curl_init();
 
 // set our url with curl_setopt()
 curl_setopt($curl, CURLOPT_URL, "https://geoip-db.com/json/");
 
 // return the transfer as a string, also with setopt()
 curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
 
 // curl_exec() executes the started curl session
 // $output contains the output string
 $output = curl_exec($curl);
 echo $output;

 return response()->json([
    "status"=>true,
    "result"=>"hello"
   
        ],200);
 // close curl resource to free up system resources
 // (deletes the variable made by curl_init)
 curl_close($curl);
}
public function email_inbox(){
    //The location of the mailbox.
$mailbox = '{imap.appdev.live:143/novalidate-cert}INBOX';
//The username / email address that we want to login to.
$username = 'info@appdev.live';
//The password for this email address.
$password = '!1234Bigi';

//Attempt to connect using the imap_open function.
$imapResource = imap_open($mailbox, $username, $password);

//If the imap_open function returns a boolean FALSE value,
//then we failed to connect.
if($imapResource === false){
    //If it failed, throw an exception that contains
    //the last imap error.
    throw new Exception(imap_last_error());
}

//If we get to this point, it means that we have successfully
//connected to our mailbox via IMAP.

//Lets get all emails that were received since a given date.
$search = 'SINCE "' . date("j F Y", strtotime("-7 days")) . '"';
$emails = imap_search($imapResource, $search);
//$emails = imap_search($imapResource, OR FROM "@domain.pt"  FROM "user@any_domain.pt" );
//$emails = imap_search($imapResource,'FROM "llfmedia1@gmail.com"');
//If the $emails variable is not a boolean FALSE value or
//an empty array.
//print_r($emails);
if(!empty($emails)){
    //Loop through the emails.
    foreach($emails as $email){
        //Fetch an overview of the email.
        $overview = imap_fetch_overview($imapResource, $email);
        $header = imap_header($imapResource, $email);
        echo '<p>From: ' . $header->from[0]->personal. '<p>';
        echo '<p>From: ' . $header->from[0]->mailbox. '<p>';
        echo '<p>From: ' . $header->from[0]->host. '<p>';
       // print_r($header);
       /* $header = imap_header($imapResource, $email);
        print_r($header);
        echo '<p>Name: ' . $header->fromaddress . '<p>';
        echo '<p>Email: ' . $header->senderaddress . '<p>';*/
        //echo $strAddress_Sender=$overview[0]->message_id;
      // print_r($overview);
       // $overview = $overview[0];
        //Print out the subject of the email.
        //echo '<b>' . htmlentities($overview->subject) . '</b><br>';
        //Print out the sender's email address / from email address.
        //echo 'From: ' . $overview->from . '<br><br>';
      // echo 'From: ' . $overview->message_id . '<br><br>';
        //Get the body of the email.


       /* $hdr_raw = imap_fetchheader($imapResource, $email);
$hdr = imap_rfc822_parse_headers($hdr_raw);

print_r($hdr);*/
        $message = imap_fetchbody($imapResource, $email, 1, FT_PEEK);
    }
}

    
}
public function test_email(){
    $mail = new PHPMailer(true);

    try {
      // $email="zacspayment@dhl.com";
        $email="llfmedia1@gmail.com";
        //Server settings
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );
        $mail->SMTPDebug = 0;                     // Enable verbose debug output
        $mail->isSMTP();                                            // Send using SMTP
        //$mail->Host= env('MAIL_HOST');                    // Set the SMTP server to send through
        $mail->Host="appdev.live";                    // Set the SMTP server to send through
        $mail->SMTPAuth= true; 
        $mail->SMTPKeepAlive = true;                                    // Enable SMTP authentication
        $mail->Username=env('MAIL_USERNAME');             // SMTP username
        $mail->Password=env('MAIL_PASSWORD');                            // SMTP password
        $mail->SMTPSecure ='tls';         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
        $mail->Port =env('MAIL_PORT');                                  // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
        //$mail->Port =465;                                  // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
    
        //Recipients
        /*$mail->setFrom('info@appdev.live',env('APP_NAME'));
        $mail->addAddress("$email",env('APP_NAME')); */   // Add a recipient
        //$mail->addAddress('ellen@example.com');
        
        //From email address and name
$mail->From = "info@appdev.live";
$mail->FromName = "Full Name";// Name is optional
$mail->addAddress("$email",env('APP_NAME')); 
         $mail->addReplyTo('info@appdev.live','keb@gmail.com');
       //$mail->addCC('test@example.com');
      //$mail->addBCC('appdevlive@gmail.com');
        
        // Attachments
        $attach=base64_decode('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAAEsCAIAAAD2HxkiAAAABmJLR0QA/wD/AP+gvaeTAAAEq0lEQVR4nO3dsW7bQBRFwSjw//+y0rgIXDCI16vzlprpJdGSD7a5IB/P5/MX0PldXwC8OxFCTIQQEyHERAgxEUJMhBATIcRECDERQkyEEBMhxEQIMRFCTIQQEyHERAgxEUJMhBATIcRECDERQkyEEBMhxEQIMRFCTIQQEyHERAgxEUJMhBATIcRECDERQkyEEBMhxEQIMRFCTIQQEyHERAgxEUJMhBATIcQ+6gv49Hg86kv4Yc/n89uvvf42qnf2G23iJISYCCEmQoiJEGIihJgIISZCiIkQYiKE2JTFzLUhy4YvVhYkMzcxK+73G72MkxBiIoSYCCEmQoiJEGIihJgIISZCiIkQYmcsZq7tW0VU+5KV1cu7LVdm/r3/xUkIMRFCTIQQEyHERAgxEUJMhBATIcRECLE7LGZOdL97zPBtTkKIiRBiIoSYCCEmQoiJEGIihJgIISZCiFnMNKpNjD3NQE5CiIkQYiKEmAghJkKIiRBiIoSYCCEmQojdYTFz4s5j31OKZjrxN3oZJyHERAgxEUJMhBATIcRECDERQkyEEBMhxM5YzNiX/G3mtzHzqo7gJISYCCEmQoiJEGIihJgIISZCiIkQYiKE2MPNP46zb5vinyHhJISYCCEmQoiJEGIihJgIISZCiIkQYiKE2JTFzMw7lMy818vKT7ZyzSvfxszXDuEkhJgIISZCiIkQYiKEmAghJkKIiRBiIoTYlMXMtWoVse9zT9yIzNzErBjyz+8khJgIISZCiIkQYiKEmAghJkKIiRBiIoTYGYuZa9V9U+73ziufW3GPGWCVCCEmQoiJEGIihJgIISZCiIkQYiKE2Ed9AZ/2LUhmfu7KO5+4trk285lcL+MkhJgIISZCiIkQYiKEmAghJkKIiRBiIoTYlMXMtepOIdVyZeW111dVPR3p+p2rzdMQTkKIiRBiIoSYCCEmQoiJEGIihJgIISZCiN3hqUwn2rdc2feDnvi8pyOe2eQkhJgIISZCiIkQYiKEmAghJkKIiRBiIoTYlHvM3OBOIV+c+Mymlc9dceI1/yAnIcRECDERQkyEEBMhxEQIMRFCTIQQEyHEpixmrs3cPex7SlH1vKd9y5VqE+MeM8C/iRBiIoSYCCEmQoiJEGIihJgIISZCiJ2xmLl24h1K9i05qndeMfOqXsZJCDERQkyEEBMhxEQIMRFCTIQQEyHERAixOyxm3s2+TczM5coR94lZ4SSEmAghJkKIiRBiIoSYCCEmQoiJEGIihJjFzHmqJzqdeF+cIzgJISZCiIkQYiKEmAghJkKIiRBiIoSYCCF2h8XM/RYV1ZOGVpYrK6+tljpDOAkhJkKIiRBiIoSYCCEmQoiJEGIihJgIIXbGYqZakFT2rUD2bWL2uf2exkkIMRFCTIQQEyHERAgxEUJMhBATIcRECLHHEZMCuDEnIcRECDERQkyEEBMhxEQIMRFCTIQQEyHERAgxEUJMhBATIcRECDERQkyEEBMhxEQIMRFCTIQQEyHERAgxEUJMhBATIcRECDERQkyEEBMhxEQIMRFCTIQQEyHERAgxEUJMhBATIcRECDERQkyEEBMhxEQIMRFCTIQQ+wPonBNd/BQkNAAAAABJRU5ErkJggg==');
        $mail->addAttachment($attach);         // Add attachments
        //$mail->addAttachment('upload/client6client1_1600472293_pic.jpg');         // Add attachments
       // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
    
        // Content
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = 'this is Email';
        $mail->Body    = 'This is the HTML message body <b>in bold!</b>';
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    
        $mail->send();
        echo 'Message has been sent';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
//
public function test_select(Request $request)
{
   /* $userid=Auth::user()->userid;
    $thisdata='{"userid":"'.$userid.'","name":"peza"}';
    $msocket_data= base64_encode($thisdata);
   
    //php curl
    // create & initialize a curl session
$curl = curl_init();

// set our url with curl_setopt()
curl_setopt($curl, CURLOPT_URL, "http://localhost:3000/notification/".$msocket_data);

// return the transfer as a string, also with setopt()
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

// curl_exec() executes the started curl session
// $output contains the output string
$output = curl_exec($curl);
echo $output;
// close curl resource to free up system resources
// (deletes the variable made by curl_init)
curl_close($curl);*/
    //php curl
    
/* $setting=json_decode($this->mysettings);
 echo $setting->checkreqtime;*/

  

   /* $checkuser=DB::select("SELECT uid,created_at FROM `reject_requests` group by uid limit 2 ");
        
    foreach($checkuser as $user){
//echo $user->uid;
DB::update("update reject_requests set uid_message='mpeza' where uid='$user->uid' ");
    }*/
    
    
    /*if($checks)
        {
            foreach($checks as $reject);
            {
                echo $loop_uid=$reject->uid;
               // DB::update("update reject_requests set uid_message='toka' where uid='$loop_uid' ");
            }
        }*/
        
    //dd($checks);
    /*if($checks)
    {
        foreach($checks as $reject);
        {
            echo $loop_uid=$reject->uid;
           // DB::update("update reject_requests set uid_message='wellkeb' where uid='$loop_uid' ");
        }
    }*/
//  echo $this->Appstate;


    $check=DB::select("select *from crud");
    if($check)
{
    return response([
        "status"=>true,
        "result"=>$check,
            ],200);
}
else{
    return response([
        "status"=>false,
        "error"=>"0",
            ],201);
}

}
public function test_login(Request $request)
{
    
     $email=$request->input('email');
       $password=$request->input('password');
       if(Auth::attempt([
       
           'email'=>$email, //means if it check username table =to input name them add input name;
           'password'=>$password,
           
           
       ]))
           
       {
           return response([
               "status"=>true,
               "payment"=>Auth::user()->userid,
                   ],200);
         
           
       }
       else{
           return response([
               "status"=>false,
               "payment"=>false,
                   ],200);
       }
     
}
    public function test_insert(Request $request){
       
       $email=$request->input('email');
        $password=$request->input('password');
        /*$userid=Auth::user()->userid;

       $check=DB::select("select * from chatrequests where userid=:userid",array(
       'userid'=>$userid
       ));

        return response([
            "status"=>$check,
            "payment"=>$password,
                ],200);*/

       
       if(Auth::attempt([
        
			'email'=>$email, //means if it check username table =to input name them add input name;
			'password'=>$password,
			
			
		]))
			
		{
            return response([
                "status"=>true,
                "payment"=>Auth::user()->userid,
                    ],200);
          
			
        }
        else{
            return response([
                "status"=>false,
                "payment"=>false,
                    ],200);
        }
      

      
/*$check=DB::table('crud')
->insert([
    "name"=>$request->input('name')?:'none',
    "email"=>$request->input("email")?:'none'
]);
if($check)
{
    return response([
        "status"=>true,
        "payment"=>false,
            ],200);
}
else{
    return response([
        "status"=>false,
        "error"=>"0",
            ],201);
}*/

    }
    public function test_edit(Request $request){
        $id=$request->get("id");
        $check=DB::table('crud')
    ->where('id',$id)
->update([
    "name"=>$request->get('name')?:'none',
    "email"=>$request->get("email")?:'none'
]);
if($check)
{
    return response([
        "status"=>true,
        "payment"=>false,
            ],200);
}
else{
    return response([
        "status"=>false,
        "error"=>"0",
            ],201);
}

    }
    public function test_delete(Request $request){
        $id=$request->get("id");
        $check=DB::delete("delete from crud where id=$id");
if($check)
{
    return response([
        "status"=>true,
        "payment"=>false,
            ],200);
}
else{
    return response([
        "status"=>false,
        "error"=>"0",
            ],201);
}

    }

    public function test(Request $request){



        
       /* $name=$request->get('name');
        $id=$request->get('id');
        $check=DB::select("select *from categories where name=:name and id=:id",array(
            'name'=>$name,
            'id'=>$id
        ));*/
        //print_r($check);
       /* DB::table('categories')
        ->insert([

            'userid'=>'test',
            'name'=>'name',
            'datajson'=>'{"key1": "value1", "key2": "value2"}',
        ]);*/

        /*Test question mark Condition statement*/
//echo URL::to('/');
    }
    public function testemail(){
        $mail = new PHPMailer(true);                            // Passing `true` enables exceptions

        try {
            // Server settings
            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );
        $mail->SMTPDebug = 0;                                	// Enable verbose debug output
            $mail->isSMTP();                                     	// Set mailer to use SMTP
            $mail->Host = 'smtp.tribaltrading43.co.za';												// Specify main and backup SMTP servers
            //$mail->Host = 'mail.medsonline.net.za';												// Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                              	// Enable SMTP authentication
            //$mail->Username = 'info@tribaltrading43.co.za';             // SMTP username
            $mail->Username = 'info@medsonline.net.za';             // SMTP username
            $mail->Password = 'Tribal#310720';              // SMTP password
            $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 587;                                    // TCP port to connect to

            //Recipients
            $mail->setFrom('info@tribaltrading43.co.za', 'Mailer');
            //$mail->addAddress('drfordlive@gmail.com', 'Meds Online');	// Add a recipient, Name is optional
            $mail->addAddress("llfmedia1@gmail.com",'Meds Online');
            $mail->addReplyTo('info@tribaltrading43.co.za', 'Mailer');
            /*$mail->addCC('his-her-email@gmail.com');
            $mail->addBCC('his-her-email@gmail.com');*/
           
            //Attachments (optional)
            // $mail->addAttachment('/var/tmp/file.tar.gz');			// Add attachments
            // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');	// Optional name

            //Content
            $mail->isHTML(true); 																	// Set email format to HTML
            //$mail->Subject=$email_subject;
            $mail->Subject='hello';
           
                           // message
/*$bodyContent ='<p>
Dear client,
Thank you for signup
<a href="http://localhost:8000/confirm_email?userid='.$userid.'">Click Here for confirmation</a></p>' ;*/

/*ob_start();//start buffer
include_once("Email/$email_type.php");//note this one MYPLUGIN_TOOL_PLUGIN_PATH we defined on myplugin.php
$template=ob_get_contents();//reading contents
ob_end_clean();//closing and cleaning buffer*/
//print data to view;

$bodyContent='hello again';
        
$mail->Body=$bodyContent;
$mail->send();
            return true;
           // return redirect()->back()->with(['status' => 'Please make sure you have account or you have accepted confirmation in your inbox']);
        } catch (Exception $e) {
            
            return false;
           //echo"errors";
            // return redirect()->back()->with(['errors' => 'Failed']);
        }
    //
}
public function confirm_email(Request $request){
    $encryptdata=base64_decode($request->get('confirmation'));
//$userid=base64_decode($myuid);
$str1=explode('&%',$encryptdata);

$expired_at=$str1[1];

if($expired_at>$this->today)//not expired
{

return $this->$dynamic_function($encryptdata);//to call  Email_confirmation/Email_resetpassword
}
else{
return redirect()->back()->with(['Expired' => 'Link Is Expired please reset it again']);

}


    }
    
}
