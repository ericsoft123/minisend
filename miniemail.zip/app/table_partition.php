<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class table_partition extends Model
{
    //
}
